import java.util.ArrayList;
import java.util.Scanner;

public class GradeTracker {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        // Adding students and their grades
        System.out.println("Enter the number of students:");
        int numStudents = scanner.nextInt();
        scanner.nextLine(); 

        for (int i = 0; i < numStudents; i++) {
            System.out.println("Enter student name:");
            String name = scanner.nextLine();
            Student student = new Student(name);

            System.out.println("Enter number of grades for " + name + ":");
            int numGrades = scanner.nextInt();
            scanner.nextLine(); 

            for (int j = 0; j < numGrades; j++) {
                System.out.println("Enter grade " + (j + 1) + ":");
                double grade = scanner.nextDouble();
                student.addGrade(grade);
            }
            students.add(student);
            scanner.nextLine(); 
        }

        // Display all student information
        System.out.println("\nStudent Information:");
        for (int i = 0; i < students.size(); i++) {
            students.get(i).displayStudentInfo();
            System.out.println("-------------------------------------------");
        }

        scanner.close();
    }
}
