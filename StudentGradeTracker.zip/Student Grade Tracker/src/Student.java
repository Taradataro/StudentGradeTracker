import java.util.ArrayList;
import java.util.Scanner;

class Student {
    String name;
    ArrayList<Double> grades;

    public Student(String name) {
        this.name = name;
        this.grades = new ArrayList<>();
    }

    public void addGrade(double grade) {
        grades.add(grade);
    }

    public double getAverageGrade() {
        double sum = 0;
      
        for (int i = 0; i < grades.size(); i++) {
            sum += grades.get(i);  
        }
        return sum / grades.size();  // Return the average grade
    }

    public void displayStudentInfo() {
        System.out.println("Student: " + name);
        System.out.println("Grades: " + grades);
        System.out.println("Average Grade: " + getAverageGrade());
    }
}